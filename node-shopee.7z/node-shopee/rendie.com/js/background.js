'use strict';
import { index } from './index.js';
index.a01();