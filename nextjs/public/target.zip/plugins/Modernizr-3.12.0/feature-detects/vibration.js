/*!
{
  "name": "Vibration API",
  "property": "vibrate",
  "caniuse": "vibration",
  "notes": [{
    "name": "MDN Docs",
    "href": "https://developer.mozilla.org/en/DOM/window.navigator.mozVibrate"
  }, {
    "name": "W3C Spec",
    "href": "https://www.w3.org/TR/vibration/"
  }]
}
!*/
/* DOC
Detects support for the API that provides access to the vibration mechanism of the hosting device, to provide tactile feedback.
*/
define(['Modernizr', 'prefixed'], function(Modernizr, prefixed) {
  Modernizr.addTest('vibrate', !!prefixed('vibrate', navigator));
});
