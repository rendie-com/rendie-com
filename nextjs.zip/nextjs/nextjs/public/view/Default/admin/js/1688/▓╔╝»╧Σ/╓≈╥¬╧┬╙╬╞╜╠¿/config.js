let MainDownstreamPlatforms=[
  {
    "name": "速卖通",
    "count": 189750
  },
  {
    "name": "亚马逊",
    "count": 182422
  },
  {
    "name": "wish",
    "count": 174489
  },
  {
    "name": "ebay",
    "count": 165447
  },
  {
    "name": "LAZADA",
    "count": 161557
  },
  {
    "name": "独立站",
    "count": 159905
  },
  {
    "name": "拼多多",
    "count": 98798
  },
  {
    "name": "抖音",
    "count": 59808
  },
  {
    "name": "天猫",
    "count": 56810
  },
  {
    "name": "shopee",
    "count": 56765
  },
  {
    "name": "SHEIN",
    "count": 54667
  },
  {
    "name": "快手",
    "count": 53812
  },
  {
    "name": "淘宝",
    "count": 52472
  },
  {
    "name": "京东",
    "count": 45806
  },
  {
    "name": "垂类电商",
    "count": 45286
  },
  {
    "name": "LINIO",
    "count": 43519
  },
  {
    "name": "阿里巴巴",
    "count": 646
  },
  {
    "name": "Joom",
    "count": 203
  },
  {
    "name": "实体工厂",
    "count": 168
  },
  {
    "name": "temu",
    "count": 116
  },
  {
    "name": "敦煌",
    "count": 114
  },
  {
    "name": "咨询客服",
    "count": 44
  },
  {
    "name": "18328127424",
    "count": 43
  },
  {
    "name": "实体店",
    "count": 41
  },
  {
    "name": "无",
    "count": 37
  },
  {
    "name": "跨境",
    "count": 29
  },
  {
    "name": "18904525367",
    "count": 25
  },
  {
    "name": "淘宝天猫",
    "count": 22
  },
  {
    "name": "线下实体",
    "count": 22
  },
  {
    "name": "1688",
    "count": 21
  },
  {
    "name": "各电商平台实体店",
    "count": 20
  },
  {
    "name": "服装包装",
    "count": 20
  },
  {
    "name": "18969844106",
    "count": 18
  },
  {
    "name": "103450644",
    "count": 16
  },
  {
    "name": "唯品会",
    "count": 16
  },
  {
    "name": "见描述",
    "count": 14
  },
  {
    "name": "外贸采购商",
    "count": 13
  },
  {
    "name": "线下厂商",
    "count": 13
  },
  {
    "name": "国内",
    "count": 13
  },
  {
    "name": "天猫淘宝",
    "count": 12
  },
  {
    "name": "国内电商",
    "count": 12
  },
  {
    "name": "19037944544",
    "count": 11
  },
  {
    "name": "19037836944",
    "count": 11
  },
  {
    "name": "Etsy",
    "count": 11
  },
  {
    "name": "亚马逊速卖通国际站",
    "count": 11
  },
  {
    "name": "中国",
    "count": 10
  },
  {
    "name": "国内外",
    "count": 10
  },
  {
    "name": "3239027",
    "count": 9
  },
  {
    "name": "19037968641",
    "count": 9
  },
  {
    "name": "见详情",
    "count": 9
  },
  {
    "name": "各平台",
    "count": 9
  },
  {
    "name": "外贸公司",
    "count": 8
  },
  {
    "name": "内贸",
    "count": 8
  },
  {
    "name": "Tiktok",
    "count": 8
  },
  {
    "name": "电商",
    "count": 8
  },
  {
    "name": "外内贸采购商",
    "count": 8
  },
  {
    "name": "24738462789",
    "count": 8
  },
  {
    "name": "逊",
    "count": 8
  },
  {
    "name": "19281176141",
    "count": 7
  },
  {
    "name": "跨境电商",
    "count": 7
  },
  {
    "name": "所有电商平台以及线下专供",
    "count": 7
  },
  {
    "name": "1688国际站",
    "count": 7
  },
  {
    "name": "10894027",
    "count": 6
  },
  {
    "name": "12593179",
    "count": 6
  },
  {
    "name": "85926907",
    "count": 6
  },
  {
    "name": "各电商平台",
    "count": 6
  },
  {
    "name": "线下",
    "count": 6
  },
  {
    "name": "沃尔玛",
    "count": 6
  },
  {
    "name": "等等",
    "count": 6
  },
  {
    "name": "19022027760",
    "count": 6
  },
  {
    "name": "18876924916",
    "count": 6
  },
  {
    "name": "跨境专供",
    "count": 6
  },
  {
    "name": "1",
    "count": 5
  },
  {
    "name": "线上",
    "count": 5
  },
  {
    "name": "阿里国际",
    "count": 5
  },
  {
    "name": "全球",
    "count": 5
  },
  {
    "name": "WISH抖音快手",
    "count": 5
  },
  {
    "name": "外贸",
    "count": 5
  },
  {
    "name": "19040010902",
    "count": 5
  },
  {
    "name": "19037921829",
    "count": 5
  },
  {
    "name": "自建站",
    "count": 5
  },
  {
    "name": "站",
    "count": 5
  },
  {
    "name": "3251747",
    "count": 4
  },
  {
    "name": "1633712377",
    "count": 4
  },
  {
    "name": "越南",
    "count": 4
  },
  {
    "name": "com",
    "count": 4
  },
  {
    "name": "二类电商",
    "count": 4
  },
  {
    "name": "查看详情",
    "count": 4
  },
  {
    "name": "速",
    "count": 4
  },
  {
    "name": "垂",
    "count": 4
  },
  {
    "name": "淘宝网",
    "count": 4
  },
  {
    "name": "WISH快手抖音",
    "count": 4
  },
  {
    "name": "WISH快手",
    "count": 4
  },
  {
    "name": "facebook",
    "count": 4
  },
  {
    "name": "执御",
    "count": 4
  },
  {
    "name": "亚马逊速卖通",
    "count": 4
  },
  {
    "name": "线上线下",
    "count": 4
  },
  {
    "name": "速卖通亚马逊wishebayLAZADA独立站抖音PDDLINIO天猫垂类电商拼多多淘宝快手京东",
    "count": 4
  },
  {
    "name": "乐天",
    "count": 4
  },
  {
    "name": "速卖通亚马逊",
    "count": 4
  },
  {
    "name": "抖音快手淘宝",
    "count": 4
  },
  {
    "name": "amazon",
    "count": 4
  },
  {
    "name": "美客多",
    "count": 4
  },
  {
    "name": "20898610133",
    "count": 4
  },
  {
    "name": "21330205758",
    "count": 4
  },
  {
    "name": "圣皮埃尔和密克隆岛",
    "count": 4
  },
  {
    "name": "123",
    "count": 3
  },
  {
    "name": "3234723",
    "count": 3
  },
  {
    "name": "3956847",
    "count": 3
  },
  {
    "name": "1633772479",
    "count": 3
  },
  {
    "name": "1959813242",
    "count": 3
  },
  {
    "name": "3017893430",
    "count": 3
  },
  {
    "name": "拼多多淘宝天猫",
    "count": 3
  },
  {
    "name": "ETSY",
    "count": 3
  },
  {
    "name": "欧美",
    "count": 3
  },
  {
    "name": "外贸采购",
    "count": 3
  },
  {
    "name": "momo",
    "count": 3
  },
  {
    "name": "港澳台",
    "count": 3
  },
  {
    "name": "贸易公司",
    "count": 3
  },
  {
    "name": "微供",
    "count": 3
  },
  {
    "name": "各大平台",
    "count": 3
  },
  {
    "name": "跨境平台",
    "count": 3
  },
  {
    "name": "直播",
    "count": 3
  },
  {
    "name": "非洲",
    "count": 3
  },
  {
    "name": "欧洲",
    "count": 3
  },
  {
    "name": "南美",
    "count": 3
  },
  {
    "name": "东南亚",
    "count": 3
  },
  {
    "name": "北美",
    "count": 3
  },
  {
    "name": "东北亚",
    "count": 3
  },
  {
    "name": "中东",
    "count": 3
  },
  {
    "name": "18858295948",
    "count": 3
  },
  {
    "name": "shopify",
    "count": 3
  },
  {
    "name": "门店",
    "count": 3
  },
  {
    "name": "Qoo10",
    "count": 3
  },
  {
    "name": "INS",
    "count": 3
  },
  {
    "name": "19320083025",
    "count": 3
  },
  {
    "name": "多平台",
    "count": 3
  },
  {
    "name": "19147864120",
    "count": 3
  },
  {
    "name": "Ozon",
    "count": 3
  },
  {
    "name": "19147661588",
    "count": 3
  },
  {
    "name": "咨询",
    "count": 3
  },
  {
    "name": "19189141673",
    "count": 3
  },
  {
    "name": "98银",
    "count": 3
  },
  {
    "name": "19123318578",
    "count": 3
  },
  {
    "name": "21719856574",
    "count": 3
  },
  {
    "name": "各大电商平台",
    "count": 3
  },
  {
    "name": "亚马逊速卖通国际站SHEIN",
    "count": 3
  },
  {
    "name": "10122",
    "count": 2
  },
  {
    "name": "7793313",
    "count": 2
  },
  {
    "name": "48670152",
    "count": 2
  },
  {
    "name": "102455095",
    "count": 2
  },
  {
    "name": "153769102",
    "count": 2
  },
  {
    "name": "205246087",
    "count": 2
  },
  {
    "name": "334844396",
    "count": 2
  },
  {
    "name": "1867970098",
    "count": 2
  },
  {
    "name": "2211397837",
    "count": 2
  },
  {
    "name": "亚马逊独立站",
    "count": 2
  },
  {
    "name": "各类跨境销售平台",
    "count": 2
  },
  {
    "name": "阿里巴巴国际",
    "count": 2
  },
  {
    "name": "淘宝天猫京东",
    "count": 2
  },
  {
    "name": "奥兹车品官方旗舰店",
    "count": 2
  },
  {
    "name": "全国",
    "count": 2
  },
  {
    "name": "国内其他电商平台",
    "count": 2
  },
  {
    "name": "1668国际站",
    "count": 2
  },
  {
    "name": "等",
    "count": 2
  },
  {
    "name": "亚马逊速卖通EBAY快手",
    "count": 2
  },
  {
    "name": "速卖通JOOM亚马逊快手",
    "count": 2
  },
  {
    "name": "速卖通亚马逊快手",
    "count": 2
  },
  {
    "name": "微商",
    "count": 2
  },
  {
    "name": "实体",
    "count": 2
  },
  {
    "name": "速卖通WISH亚马逊",
    "count": 2
  },
  {
    "name": "速卖通WISH亚马逊EBAY",
    "count": 2
  },
  {
    "name": "国际阿里巴巴",
    "count": 2
  },
  {
    "name": "19284116253",
    "count": 2
  },
  {
    "name": "全部",
    "count": 2
  },
  {
    "name": "AMazon",
    "count": 2
  },
  {
    "name": "微信",
    "count": 2
  },
  {
    "name": "速卖通俄罗斯WISH",
    "count": 2
  },
  {
    "name": "实体企业",
    "count": 2
  },
  {
    "name": "淘宝天猫抖音",
    "count": 2
  },
  {
    "name": "阿里巴巴国际区",
    "count": 2
  },
  {
    "name": "wish亚马逊速卖通独立站LAZADAebay",
    "count": 2
  },
  {
    "name": "阿里",
    "count": 2
  },
  {
    "name": "实体批发",
    "count": 2
  },
  {
    "name": "其他电商平台",
    "count": 2
  },
  {
    "name": "21059628450",
    "count": 2
  },
  {
    "name": "拼duoduo",
    "count": 2
  },
  {
    "name": "Walmart",
    "count": 2
  },
  {
    "name": "19104496378",
    "count": 2
  },
  {
    "name": "抖店",
    "count": 2
  },
  {
    "name": "国内电商平台",
    "count": 2
  },
  {
    "name": "19147829257",
    "count": 2
  },
  {
    "name": "阿里国际站其他",
    "count": 2
  },
  {
    "name": "所有平台",
    "count": 2
  },
  {
    "name": "淘宝京东ebayPDD亚马逊wish快手LINIOSHEIN速卖通天猫",
    "count": 2
  },
  {
    "name": "20950325656",
    "count": 2
  },
  {
    "name": "经销处",
    "count": 2
  },
  {
    "name": "19057944264",
    "count": 2
  },
  {
    "name": "拼多多等",
    "count": 2
  },
  {
    "name": "26160065024",
    "count": 2
  },
  {
    "name": "22133891170",
    "count": 2
  },
  {
    "name": "18628809468",
    "count": 2
  },
  {
    "name": "20950330182",
    "count": 2
  },
  {
    "name": "19313884587",
    "count": 2
  },
  {
    "name": "24054223617",
    "count": 2
  },
  {
    "name": "coupang",
    "count": 2
  },
  {
    "name": "淘特",
    "count": 2
  },
  {
    "name": "速卖通国际站亚马逊wish",
    "count": 2
  },
  {
    "name": "否",
    "count": 2
  },
  {
    "name": "19126747610",
    "count": 2
  },
  {
    "name": "20249163876",
    "count": 2
  },
  {
    "name": "20249163877",
    "count": 2
  },
  {
    "name": "速卖通AliExpress",
    "count": 2
  },
  {
    "name": "taobao",
    "count": 2
  },
  {
    "name": "实体淘宝抖音",
    "count": 2
  },
  {
    "name": "淘宝天猫抖音跨境平台专供",
    "count": 2
  },
  {
    "name": "Shopify",
    "count": 2
  },
  {
    "name": "Shpee",
    "count": 2
  },
  {
    "name": "3585",
    "count": 1
  },
  {
    "name": "21959",
    "count": 1
  },
  {
    "name": "27013",
    "count": 1
  },
  {
    "name": "45989",
    "count": 1
  },
  {
    "name": "85439",
    "count": 1
  },
  {
    "name": "3234063",
    "count": 1
  },
  {
    "name": "3580298",
    "count": 1
  },
  {
    "name": "4932810",
    "count": 1
  },
  {
    "name": "7350061",
    "count": 1
  },
  {
    "name": "7603787",
    "count": 1
  },
  {
    "name": "11005002",
    "count": 1
  },
  {
    "name": "13407634",
    "count": 1
  },
  {
    "name": "16710320",
    "count": 1
  },
  {
    "name": "32657200",
    "count": 1
  },
  {
    "name": "38155433",
    "count": 1
  },
  {
    "name": "58815252",
    "count": 1
  },
  {
    "name": "223002652",
    "count": 1
  },
  {
    "name": "631824003",
    "count": 1
  },
  {
    "name": "861158668",
    "count": 1
  },
  {
    "name": "1153394719",
    "count": 1
  },
  {
    "name": "1431330275",
    "count": 1
  },
  {
    "name": "1782100466",
    "count": 1
  },
  {
    "name": "1864375291",
    "count": 1
  },
  {
    "name": "1864823822",
    "count": 1
  },
  {
    "name": "1875025670",
    "count": 1
  },
  {
    "name": "1956760306",
    "count": 1
  },
  {
    "name": "1957439974",
    "count": 1
  },
  {
    "name": "2291016101",
    "count": 1
  },
  {
    "name": "2333022128",
    "count": 1
  },
  {
    "name": "2504310883",
    "count": 1
  },
  {
    "name": "3364219377",
    "count": 1
  },
  {
    "name": "3768965693",
    "count": 1
  },
  {
    "name": "微店",
    "count": 1
  },
  {
    "name": "各实体店",
    "count": 1
  },
  {
    "name": "电商平台",
    "count": 1
  },
  {
    "name": "天气之子项链",
    "count": 1
  },
  {
    "name": "20725923000",
    "count": 1
  },
  {
    "name": "q'q",
    "count": 1
  },
  {
    "name": "21173111733",
    "count": 1
  },
  {
    "name": "19615351921",
    "count": 1
  },
  {
    "name": "20278265640",
    "count": 1
  },
  {
    "name": "品多多",
    "count": 1
  },
  {
    "name": "国内市场",
    "count": 1
  },
  {
    "name": "ASI",
    "count": 1
  },
  {
    "name": "choker颈链组合",
    "count": 1
  },
  {
    "name": "19129554559",
    "count": 1
  },
  {
    "name": "拼多多京东",
    "count": 1
  },
  {
    "name": "速卖通爆款",
    "count": 1
  },
  {
    "name": "19310541487",
    "count": 1
  },
  {
    "name": "19189068801",
    "count": 1
  },
  {
    "name": "CDISCOUNT",
    "count": 1
  },
  {
    "name": "京东淘宝",
    "count": 1
  },
  {
    "name": "19118878826",
    "count": 1
  },
  {
    "name": "批发市场",
    "count": 1
  },
  {
    "name": "20818575591",
    "count": 1
  },
  {
    "name": "兰亭",
    "count": 1
  },
  {
    "name": "电视购物",
    "count": 1
  },
  {
    "name": "实体店铺",
    "count": 1
  },
  {
    "name": "自有品牌",
    "count": 1
  },
  {
    "name": "外贸公司定制",
    "count": 1
  },
  {
    "name": "其它平台",
    "count": 1
  },
  {
    "name": "Dhgate",
    "count": 1
  },
  {
    "name": "27995177038",
    "count": 1
  },
  {
    "name": "环球易购",
    "count": 1
  },
  {
    "name": "拼多多抖音",
    "count": 1
  },
  {
    "name": "网络平台",
    "count": 1
  },
  {
    "name": "代理",
    "count": 1
  },
  {
    "name": "wish>亚马逊>独立站>速卖通>LAZADA>ebay",
    "count": 1
  },
  {
    "name": "独立柱",
    "count": 1
  },
  {
    "name": "jumia",
    "count": 1
  },
  {
    "name": "kilimall",
    "count": 1
  },
  {
    "name": "20777931607",
    "count": 1
  },
  {
    "name": "20454159355",
    "count": 1
  },
  {
    "name": "亚马逊外贸ebay",
    "count": 1
  },
  {
    "name": "京东微商",
    "count": 1
  },
  {
    "name": "天猫淘宝拼多多",
    "count": 1
  },
  {
    "name": "兰亭集势",
    "count": 1
  },
  {
    "name": "外贸平台",
    "count": 1
  },
  {
    "name": "淘宝天猫京东实体店亚马逊速卖通抖音拼多多",
    "count": 1
  },
  {
    "name": "20815323027",
    "count": 1
  },
  {
    "name": "19330391515",
    "count": 1
  },
  {
    "name": "FACEBOOK",
    "count": 1
  },
  {
    "name": "香港澳门台湾",
    "count": 1
  },
  {
    "name": "南亚",
    "count": 1
  },
  {
    "name": "19556945855",
    "count": 1
  },
  {
    "name": "29081959285",
    "count": 1
  },
  {
    "name": "速卖通JOOM亚马逊快手抖音",
    "count": 1
  },
  {
    "name": "速卖通JOOM亚马逊WISH快手",
    "count": 1
  },
  {
    "name": "ebaywish速卖通独立站LAZADA",
    "count": 1
  },
  {
    "name": "线下贸易公司",
    "count": 1
  },
  {
    "name": "19283992781",
    "count": 1
  },
  {
    "name": "20610739356",
    "count": 1
  },
  {
    "name": "书店",
    "count": 1
  },
  {
    "name": "学校",
    "count": 1
  },
  {
    "name": "速卖通亚马逊JOOM快手",
    "count": 1
  },
  {
    "name": "独立站站",
    "count": 1
  },
  {
    "name": "外贸订单",
    "count": 1
  },
  {
    "name": "展会",
    "count": 1
  },
  {
    "name": "天猫等",
    "count": 1
  },
  {
    "name": "速卖通EBAY亚马逊",
    "count": 1
  },
  {
    "name": "winh",
    "count": 1
  },
  {
    "name": "速卖通亚马逊跨境地摊",
    "count": 1
  },
  {
    "name": "国内任何电商平台",
    "count": 1
  },
  {
    "name": "速卖通亚马逊EBAY",
    "count": 1
  },
  {
    "name": "做货周期",
    "count": 1
  },
  {
    "name": "19777610498",
    "count": 1
  },
  {
    "name": "19623361887",
    "count": 1
  },
  {
    "name": "脸书",
    "count": 1
  },
  {
    "name": "19660975868",
    "count": 1
  },
  {
    "name": "外网站",
    "count": 1
  },
  {
    "name": "其他平台",
    "count": 1
  },
  {
    "name": "TM天猫",
    "count": 1
  },
  {
    "name": "国内平台",
    "count": 1
  },
  {
    "name": "是",
    "count": 1
  },
  {
    "name": "19564967731",
    "count": 1
  },
  {
    "name": "LADAZA",
    "count": 1
  },
  {
    "name": "21755195499",
    "count": 1
  },
  {
    "name": "欧美商超",
    "count": 1
  },
  {
    "name": "22046051134",
    "count": 1
  },
  {
    "name": "19552212583",
    "count": 1
  },
  {
    "name": "全部外贸平台",
    "count": 1
  },
  {
    "name": "详询商家",
    "count": 1
  },
  {
    "name": "NOON",
    "count": 1
  },
  {
    "name": "19328200795",
    "count": 1
  },
  {
    "name": "24362554126",
    "count": 1
  },
  {
    "name": "LZADA",
    "count": 1
  },
  {
    "name": "国内零售批发",
    "count": 1
  },
  {
    "name": "淘货源",
    "count": 1
  },
  {
    "name": "采源宝",
    "count": 1
  },
  {
    "name": "线上批发零售",
    "count": 1
  },
  {
    "name": "shopity",
    "count": 1
  },
  {
    "name": "20698531931",
    "count": 1
  },
  {
    "name": "19347436708",
    "count": 1
  },
  {
    "name": "21212429459",
    "count": 1
  },
  {
    "name": "代理商",
    "count": 1
  },
  {
    "name": "经销批发",
    "count": 1
  },
  {
    "name": "外贸内销",
    "count": 1
  },
  {
    "name": "淘宝天猫拼多多",
    "count": 1
  },
  {
    "name": "20026686691",
    "count": 1
  },
  {
    "name": "都有",
    "count": 1
  },
  {
    "name": "亚马逊WISH速卖通",
    "count": 1
  },
  {
    "name": "shoppee",
    "count": 1
  },
  {
    "name": "速买通",
    "count": 1
  },
  {
    "name": "独",
    "count": 1
  },
  {
    "name": "19878239563",
    "count": 1
  },
  {
    "name": "sopee",
    "count": 1
  },
  {
    "name": "21191762142",
    "count": 1
  },
  {
    "name": "6931275029",
    "count": 1
  },
  {
    "name": "抖音淘宝",
    "count": 1
  },
  {
    "name": "Shoppe",
    "count": 1
  },
  {
    "name": "19126722964",
    "count": 1
  },
  {
    "name": "C电",
    "count": 1
  },
  {
    "name": "abey",
    "count": 1
  },
  {
    "name": "跨境电商平台",
    "count": 1
  },
  {
    "name": "20115734082",
    "count": 1
  },
  {
    "name": "20900086328",
    "count": 1
  },
  {
    "name": "抖音淘宝快手",
    "count": 1
  },
  {
    "name": "19633630318",
    "count": 1
  },
  {
    "name": "Abay",
    "count": 1
  },
  {
    "name": "13862607833",
    "count": 1
  },
  {
    "name": "淘工厂",
    "count": 1
  },
  {
    "name": "淘宝天猫等",
    "count": 1
  },
  {
    "name": "21059614607",
    "count": 1
  },
  {
    "name": "24085825148",
    "count": 1
  },
  {
    "name": "21030095349",
    "count": 1
  },
  {
    "name": "20579884155",
    "count": 1
  },
  {
    "name": "大陆",
    "count": 1
  },
  {
    "name": "19343570389",
    "count": 1
  },
  {
    "name": "详询卖家",
    "count": 1
  },
  {
    "name": "21058526546",
    "count": 1
  },
  {
    "name": "AliExpress",
    "count": 1
  },
  {
    "name": "27909076378",
    "count": 1
  },
  {
    "name": "商超",
    "count": 1
  },
  {
    "name": "阿里速卖通",
    "count": 1
  },
  {
    "name": "vova",
    "count": 1
  },
  {
    "name": "bvay",
    "count": 1
  },
  {
    "name": "27819429481",
    "count": 1
  },
  {
    "name": "23640217103",
    "count": 1
  },
  {
    "name": "19227973654",
    "count": 1
  },
  {
    "name": "虾皮等",
    "count": 1
  },
  {
    "name": "淘宝亚马逊等",
    "count": 1
  },
  {
    "name": "短视频直播",
    "count": 1
  },
  {
    "name": "*",
    "count": 1
  },
  {
    "name": "20249932021",
    "count": 1
  },
  {
    "name": "20477928551",
    "count": 1
  },
  {
    "name": "20828656247",
    "count": 1
  },
  {
    "name": "Coupang",
    "count": 1
  },
  {
    "name": "23776598120",
    "count": 1
  },
  {
    "name": "花店及线上网店",
    "count": 1
  },
  {
    "name": "全平台",
    "count": 1
  },
  {
    "name": "虾皮速卖通亚马逊",
    "count": 1
  },
  {
    "name": "19312073802",
    "count": 1
  },
  {
    "name": "aliexpress",
    "count": 1
  },
  {
    "name": "qt0368",
    "count": 1
  },
  {
    "name": "独立",
    "count": 1
  },
  {
    "name": "LINI",
    "count": 1
  },
  {
    "name": "跨境速卖通虾皮",
    "count": 1
  },
  {
    "name": "NULL",
    "count": 1
  },
  {
    "name": "ADAZA",
    "count": 1
  },
  {
    "name": "webay",
    "count": 1
  },
  {
    "name": "亚马逊国际站速卖通",
    "count": 1
  },
  {
    "name": "7327169552",
    "count": 1
  },
  {
    "name": "19328869402",
    "count": 1
  },
  {
    "name": "商场",
    "count": 1
  },
  {
    "name": "19622911755",
    "count": 1
  },
  {
    "name": "19626247159",
    "count": 1
  },
  {
    "name": "零售批发",
    "count": 1
  },
  {
    "name": "我们公司",
    "count": 1
  },
  {
    "name": "根据客户要求",
    "count": 1
  },
  {
    "name": "欧洲北美南美东南亚东北亚中东非洲",
    "count": 1
  },
  {
    "name": "海外购物平台",
    "count": 1
  },
  {
    "name": "各种平台",
    "count": 1
  },
  {
    "name": "ppd",
    "count": 1
  },
  {
    "name": "20768622497",
    "count": 1
  },
  {
    "name": "20768642203",
    "count": 1
  },
  {
    "name": "21330236755",
    "count": 1
  },
  {
    "name": "京东等",
    "count": 1
  },
  {
    "name": "R33-03-15",
    "count": 1
  },
  {
    "name": "速卖通…",
    "count": 1
  },
  {
    "name": "19619812168",
    "count": 1
  },
  {
    "name": "19972840936",
    "count": 1
  },
  {
    "name": "21662804588",
    "count": 1
  },
  {
    "name": "20577445058",
    "count": 1
  },
  {
    "name": "淘宝等各大电商平台",
    "count": 1
  },
  {
    "name": "21738312234",
    "count": 1
  },
  {
    "name": "19328823293",
    "count": 1
  },
  {
    "name": "天猫国际",
    "count": 1
  },
  {
    "name": "21768110865",
    "count": 1
  },
  {
    "name": "21990325169",
    "count": 1
  },
  {
    "name": "淘宝京东ebay亚马逊wish快手SHEIN速卖通天猫独立站LAZADA拼多多shopee抖音",
    "count": 1
  },
  {
    "name": "淘宝天猫各大电商平台",
    "count": 1
  },
  {
    "name": "非洲欧洲南美东南亚北美东北亚中东",
    "count": 1
  },
  {
    "name": "批发",
    "count": 1
  },
  {
    "name": "21288743343",
    "count": 1
  },
  {
    "name": "22078640792",
    "count": 1
  },
  {
    "name": "qs3578xd4523ky3845",
    "count": 1
  },
  {
    "name": "R8523",
    "count": 1
  },
  {
    "name": "23453083773",
    "count": 1
  },
  {
    "name": "R1056",
    "count": 1
  },
  {
    "name": "21854411915",
    "count": 1
  },
  {
    "name": "19328364411",
    "count": 1
  },
  {
    "name": "速卖通等各大跨境平台",
    "count": 1
  },
  {
    "name": "R1523",
    "count": 1
  },
  {
    "name": "20950746839",
    "count": 1
  },
  {
    "name": "22569018185",
    "count": 1
  },
  {
    "name": "19520966392",
    "count": 1
  },
  {
    "name": "21345598093",
    "count": 1
  },
  {
    "name": "shope",
    "count": 1
  },
  {
    "name": "国外大型超市",
    "count": 1
  },
  {
    "name": "圣诞树厂家配件供应",
    "count": 1
  },
  {
    "name": "阿里巴巴国际站等",
    "count": 1
  },
  {
    "name": "5682065950",
    "count": 1
  },
  {
    "name": "13379907607",
    "count": 1
  },
  {
    "name": "21387908290",
    "count": 1
  },
  {
    "name": "19303446324",
    "count": 1
  },
  {
    "name": "22675410551",
    "count": 1
  },
  {
    "name": "22693789649",
    "count": 1
  },
  {
    "name": "23801068726",
    "count": 1
  },
  {
    "name": "XD5023KY4578",
    "count": 1
  },
  {
    "name": "22055578835",
    "count": 1
  },
  {
    "name": "XD8023XB5312",
    "count": 1
  },
  {
    "name": "22374961152",
    "count": 1
  },
  {
    "name": "26159984271",
    "count": 1
  },
  {
    "name": "Herlook",
    "count": 1
  },
  {
    "name": "23158180342",
    "count": 1
  },
  {
    "name": "24424709420",
    "count": 1
  },
  {
    "name": "24339104149",
    "count": 1
  },
  {
    "name": "Target",
    "count": 1
  },
  {
    "name": "Newegg",
    "count": 1
  },
  {
    "name": "allegro",
    "count": 1
  },
  {
    "name": "MercadoLibre",
    "count": 1
  },
  {
    "name": "Zalando",
    "count": 1
  },
  {
    "name": "Wayfair",
    "count": 1
  },
  {
    "name": "Cdiscount",
    "count": 1
  },
  {
    "name": "Best",
    "count": 1
  },
  {
    "name": "Buy",
    "count": 1
  },
  {
    "name": "Flipkart",
    "count": 1
  },
  {
    "name": "shop",
    "count": 1
  },
  {
    "name": "22194825326",
    "count": 1
  },
  {
    "name": "21617788757",
    "count": 1
  },
  {
    "name": "pdd",
    "count": 1
  },
  {
    "name": "b2c",
    "count": 1
  },
  {
    "name": "五金商超",
    "count": 1
  },
  {
    "name": "xiyin",
    "count": 1
  },
  {
    "name": "22055538632",
    "count": 1
  },
  {
    "name": "内销外销",
    "count": 1
  },
  {
    "name": "22173202124",
    "count": 1
  },
  {
    "name": "19449040982",
    "count": 1
  },
  {
    "name": "19536282608",
    "count": 1
  },
  {
    "name": "21424400725",
    "count": 1
  },
  {
    "name": "8926800316",
    "count": 1
  },
  {
    "name": "5517538146",
    "count": 1
  },
  {
    "name": "0000",
    "count": 1
  },
  {
    "name": "R6023",
    "count": 1
  },
  {
    "name": "22730890198",
    "count": 1
  },
  {
    "name": "内销平台实体零售外贸商",
    "count": 1
  },
  {
    "name": "代理商等",
    "count": 1
  },
  {
    "name": "国内及跨境电商",
    "count": 1
  },
  {
    "name": "21474523549",
    "count": 1
  },
  {
    "name": "22028375575",
    "count": 1
  },
  {
    "name": "速卖糖",
    "count": 1
  },
  {
    "name": "19314254983",
    "count": 1
  },
  {
    "name": "19147817499",
    "count": 1
  },
  {
    "name": "微店等",
    "count": 1
  },
  {
    "name": "亚马逊速卖通国际站拼多多跨境SHEIN",
    "count": 1
  },
  {
    "name": "工厂",
    "count": 1
  },
  {
    "name": "19147749664",
    "count": 1
  },
  {
    "name": "不限",
    "count": 1
  },
  {
    "name": "义乌购",
    "count": 1
  },
  {
    "name": "亚马逊速卖通国际站SHEIN拼多多跨境",
    "count": 1
  },
  {
    "name": "21810900617",
    "count": 1
  },
  {
    "name": "R4055",
    "count": 1
  },
  {
    "name": "R2628",
    "count": 1
  },
  {
    "name": "亚马逊ebay独立站",
    "count": 1
  },
  {
    "name": "TIK",
    "count": 1
  },
  {
    "name": "TOK",
    "count": 1
  },
  {
    "name": "TEMO",
    "count": 1
  },
  {
    "name": "淘宝拼多多快手跨境",
    "count": 1
  },
  {
    "name": "R4212",
    "count": 1
  },
  {
    "name": "XB3012XD3245",
    "count": 1
  },
  {
    "name": "速卖通等",
    "count": 1
  },
  {
    "name": "亚马逊天猫淘宝拼多多",
    "count": 1
  },
  {
    "name": "27259477738",
    "count": 1
  },
  {
    "name": "通用",
    "count": 1
  },
  {
    "name": "26570681537",
    "count": 1
  },
  {
    "name": "26571048358",
    "count": 1
  },
  {
    "name": "亚马逊速卖通独立站",
    "count": 1
  },
  {
    "name": "26570864862",
    "count": 1
  },
  {
    "name": "R2012",
    "count": 1
  },
  {
    "name": "各类跨境电商平台",
    "count": 1
  },
  {
    "name": "各类国内电商平台",
    "count": 1
  },
  {
    "name": "线下商超",
    "count": 1
  },
  {
    "name": "亚马逊速卖通国际站wish",
    "count": 1
  },
  {
    "name": "速卖通亚马逊Wish",
    "count": 1
  },
  {
    "name": "27413397505",
    "count": 1
  },
  {
    "name": "小红书",
    "count": 1
  },
  {
    "name": "生产商",
    "count": 1
  },
  {
    "name": "22160173012",
    "count": 1
  },
  {
    "name": "各大电商平台和线下批发商",
    "count": 1
  },
  {
    "name": "国内外各大电商平台丶线下商家",
    "count": 1
  },
  {
    "name": "京东ebayPDD亚马逊wish快手LINIOSHEIN速卖通天猫独立站LAZ",
    "count": 1
  },
  {
    "name": "淘宝京东ebayPDDwish快手SHEIN速卖通天猫LAZADA拼多多sho",
    "count": 1
  },
  {
    "name": "各大电商",
    "count": 1
  },
  {
    "name": "批发商",
    "count": 1
  },
  {
    "name": "19161990926",
    "count": 1
  },
  {
    "name": "淘宝天猫抖音亚马逊",
    "count": 1
  },
  {
    "name": "19126747611",
    "count": 1
  },
  {
    "name": "19126747612",
    "count": 1
  },
  {
    "name": "19223844382",
    "count": 1
  },
  {
    "name": "20207612085",
    "count": 1
  },
  {
    "name": "20439601031",
    "count": 1
  },
  {
    "name": "20963146030",
    "count": 1
  },
  {
    "name": "21426474556",
    "count": 1
  },
  {
    "name": "21599062243",
    "count": 1
  },
  {
    "name": "28228873827",
    "count": 1
  },
  {
    "name": "跨境拼多多",
    "count": 1
  },
  {
    "name": "bay",
    "count": 1
  },
  {
    "name": "20698567176",
    "count": 1
  },
  {
    "name": "21679345956",
    "count": 1
  },
  {
    "name": "21679345959",
    "count": 1
  },
  {
    "name": "淘宝天猫等电商平台",
    "count": 1
  },
  {
    "name": "20976724407",
    "count": 1
  },
  {
    "name": "自产自销",
    "count": 1
  },
  {
    "name": "19375220507",
    "count": 1
  },
  {
    "name": "抖音等",
    "count": 1
  },
  {
    "name": "淘宝京东ebayPDD亚马逊wish快手LINIOSHEIN速卖通天猫独立站",
    "count": 1
  },
  {
    "name": "零售平台",
    "count": 1
  },
  {
    "name": "抖音等等",
    "count": 1
  },
  {
    "name": "22492671559",
    "count": 1
  },
  {
    "name": "24776677066",
    "count": 1
  },
  {
    "name": "24776677070",
    "count": 1
  },
  {
    "name": "马亚逊",
    "count": 1
  },
  {
    "name": "内销",
    "count": 1
  },
  {
    "name": "优苳冈®",
    "count": 1
  },
  {
    "name": "不支持",
    "count": 1
  },
  {
    "name": "淘宝京东天猫",
    "count": 1
  },
  {
    "name": "22484938377",
    "count": 1
  },
  {
    "name": "24636855383",
    "count": 1
  },
  {
    "name": "24636855387",
    "count": 1
  },
  {
    "name": "网销",
    "count": 1
  },
  {
    "name": "20816114821",
    "count": 1
  },
  {
    "name": "19328148902",
    "count": 1
  },
  {
    "name": "各类人群",
    "count": 1
  },
  {
    "name": "21011676011",
    "count": 1
  },
  {
    "name": "30411569023",
    "count": 1
  },
  {
    "name": "19116435239",
    "count": 1
  },
  {
    "name": "5CM以下",
    "count": 1
  },
  {
    "name": "国际站1688",
    "count": 1
  },
  {
    "name": "全域网销",
    "count": 1
  },
  {
    "name": "详询客服",
    "count": 1
  },
  {
    "name": "实体店批发",
    "count": 1
  },
  {
    "name": "线上线下平台",
    "count": 1
  },
  {
    "name": "13333563565",
    "count": 1
  },
  {
    "name": "19332278725",
    "count": 1
  },
  {
    "name": "视频号",
    "count": 1
  },
  {
    "name": "20849928732",
    "count": 1
  }
]