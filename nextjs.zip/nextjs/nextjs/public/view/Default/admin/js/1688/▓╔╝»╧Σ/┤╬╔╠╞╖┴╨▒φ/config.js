let config={
  "proList_state_count": [
    340543,
    2223,
    5105,
    11,
    0,
    0,
    1673,
    134,
    40,
    0,
    0,
    0,
    0,
    0,
    0
  ]
}